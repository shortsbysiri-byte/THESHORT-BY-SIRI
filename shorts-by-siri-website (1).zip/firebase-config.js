// ---------- Firebase project config ----------
// 1. Go to https://console.firebase.google.com -> create a free project
// 2. Project settings -> General -> "Your apps" -> Add app -> Web (</>) -> register it
// 3. Copy the config object Firebase gives you and paste the values below
// 4. In the Firebase console, enable: Authentication (Email/Password provider),
//    Firestore Database, and Storage. See README.md for full step-by-step setup
//    and the security rules to paste in.
const firebaseConfig = {
  apiKey: "AIzaSyCbtmYTpUc-IQRnqii5OcGAFZy4Tqmjx6k",
  authDomain: "shorts-by-siri.firebaseapp.com",
  projectId: "shorts-by-siri",
  storageBucket: "shorts-by-siri.firebasestorage.app",
  messagingSenderId: "1008652602124",
  appId: "1:1008652602124:web:3103cc0e9f3823ec2b1729"
};

function isFirebaseConfigured(){
  return firebaseConfig.apiKey !== "YOUR_API_KEY";
}

let fbApp, db, auth, storage;
if (isFirebaseConfigured() && window.firebase){
  fbApp = firebase.initializeApp(firebaseConfig);
  db = firebase.firestore();
  auth = firebase.auth();
  storage = firebase.storage();
}
