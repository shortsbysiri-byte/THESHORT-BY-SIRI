// ---------- Booking date: no past dates ----------
const dateInput = document.getElementById('date');
const today = new Date().toISOString().split('T')[0];
if (dateInput) dateInput.setAttribute('min', today);

// ---------- EmailJS (optional — sends you an email instantly) ----------
// 1. Create a free account at https://www.emailjs.com
// 2. Add an Email Service (e.g. Gmail) -> copy its Service ID below
// 3. Create an Email Template with variables matching the ones sent below -> copy its Template ID
// 4. Account > General > copy your Public Key
const EMAILJS_PUBLIC_KEY  = 'YOUR_PUBLIC_KEY';
const EMAILJS_SERVICE_ID  = 'YOUR_SERVICE_ID';
const EMAILJS_TEMPLATE_ID = 'YOUR_TEMPLATE_ID';

const emailJsReady = !!(window.emailjs && EMAILJS_PUBLIC_KEY !== 'YOUR_PUBLIC_KEY');
if (emailJsReady){
  emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });
}

// ---------- Firestore (optional — saves every request to your admin dashboard) ----------
function firestoreReady(){
  return typeof isFirebaseConfigured === 'function' && isFirebaseConfigured() && window.db;
}

const form = document.getElementById('bookingForm');
if (form){
  const submitBtn = document.getElementById('submitBtn');
  const statusEl = document.getElementById('formStatus');

  form.addEventListener('submit', async function(e){
    e.preventDefault();

    if (!form.checkValidity()){
      form.reportValidity();
      return;
    }

    if (!emailJsReady && !firestoreReady()){
      statusEl.textContent = 'Booking form isn\'t connected yet — set up EmailJS and/or Firebase to start receiving requests.';
      statusEl.className = 'form-status error';
      return;
    }

    const params = {
      name: form.name.value.trim(),
      phone: form.phone.value.trim(),
      email: form.email.value.trim(),
      service: form.service.value,
      date: form.date.value,
      location: form.location.value.trim(),
      message: form.message.value.trim(),
    };

    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending…';
    statusEl.textContent = '';
    statusEl.className = 'form-status';

    let savedToDashboard = false;
    let emailSent = false;

    if (firestoreReady()){
      try{
        await db.collection('bookings').add({
          ...params,
          status: 'new',
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        savedToDashboard = true;
      }catch(err){
        console.error('Firestore booking save failed:', err);
      }
    }

    if (emailJsReady){
      try{
        await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, params);
        emailSent = true;
      }catch(err){
        console.error('EmailJS error:', err);
      }
    }

    if (emailSent || savedToDashboard){
      statusEl.textContent = 'Thanks! Your booking request has been sent — I\'ll be in touch within 24 hours.';
      statusEl.className = 'form-status success';
      form.reset();
      dateInput.setAttribute('min', today);
    } else {
      statusEl.textContent = 'Something went wrong sending your request. Please try again or reach out directly.';
      statusEl.className = 'form-status error';
    }

    submitBtn.disabled = false;
    submitBtn.textContent = 'Send booking request';
  });
}
