# Shorts By Siri — Website Files

## Pages
- `index.html` — homepage (hero, a few highlighted photos, about, booking)
- `gallery.html` — full gallery, every photo
- `admin.html` — password-protected page for you (the agent) to add, highlight, or delete photos. **Not linked anywhere on the public site** — bookmark it yourself. Customers will never stumble onto it, but anyone with the link and no login still can't see or change anything without your email + password.

## Folder structure
```
index.html
gallery.html
admin.html
style.css
common.js          nav + footer (all pages)
background.js      locked scrolling background (home + gallery)
booking.js         booking form + EmailJS (home only)
gallery.js         gallery fetching/rendering + lightbox (all pages)
admin.js           admin panel logic (admin only)
firebase-config.js your Firebase project keys — fill this in
assets/
  gallery/g1.jpg … g13.jpg   original 13 gallery photos
  bg/bg1.jpg … bg5.jpg       the 5 locked scrolling background photos
```

## Setting up the admin panel (one-time, ~15 minutes)
The add/delete panel needs a small free backend to store your photo list and files. This uses **Firebase** (Google's free tier — plenty for a personal gallery site).

1. **Create a project.** Go to https://console.firebase.google.com → *Add project* → give it any name → finish the wizard.
2. **Register a web app.** In your new project, click the `</>` (web) icon → give it a nickname → *Register app*. Firebase shows you a `firebaseConfig` object with values like `apiKey`, `authDomain`, etc. Copy each value into `firebase-config.js` in this folder, replacing the `YOUR_...` placeholders.
3. **Turn on Authentication.** In the left sidebar → *Build → Authentication → Get started*. Under *Sign-in method*, enable **Email/Password**. Then go to the *Users* tab → *Add user* → enter the email and password you (the agent) want to log into `admin.html` with.
4. **Turn on Firestore.** Left sidebar → *Build → Firestore Database → Create database*. Choose *Start in production mode*, pick any region close to you.
5. **Turn on Storage.** Left sidebar → *Build → Storage → Get started*. Keep the default settings.
6. **Set security rules** so photos are publicly viewable but only you can add/change/delete them.

   In **Firestore → Rules**, replace the contents with:
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /gallery/{docId} {
         allow read: if true;
         allow write: if request.auth != null;
       }
       match /meta/{docId} {
         allow read, write: if request.auth != null;
       }
       match /bookings/{docId} {
         allow create: if true;
         allow read, update, delete: if request.auth != null;
       }
     }
   }
   ```
   In **Storage → Rules**, replace the contents with:
   ```
   rules_version = '2';
   service firebase.storage {
     match /b/{bucket}/o {
       match /{allPaths=**} {
         allow read: if true;
         allow write: if request.auth != null;
       }
     }
   }
   ```
   Click *Publish* on both.

7. **Open `admin.html`** (locally, or once hosted), sign in with the email/password from step 3, and click **"Import starter photos"** once — this brings your original 13 photos into the manageable system so they can be highlighted or deleted just like new uploads. Then use the **Add a new photo** form any time you want to add more — nothing you already have gets removed.

Until you complete this setup, the homepage and gallery page automatically show the original 13 photos from the `assets` folder as a fallback, so the site works fine before you connect Firebase — you just won't be able to add/delete through the browser yet.

## Changing a photo without the admin panel
You can still just overwrite a file in `assets/gallery/` or `assets/bg/` with a new image of the same name — see the earlier instructions. This always works, Firebase or not, for the *original* 13 photos and 5 backgrounds.

## Hosting
Upload the whole folder to any static host — Netlify, Vercel, GitHub Pages, or your own hosting. Keep every file and the `assets` folder together in the same structure. The admin panel and dynamic gallery work the same once hosted, as long as `firebase-config.js` is filled in.

## Booking requests dashboard
Once Firebase is connected (same setup as above — no extra steps needed), every booking form submission is automatically saved to Firestore and shows up in **`admin.html` → Booking requests**, with the requester's details, a status you can click to cycle through New → Contacted → Done, and a delete button. This works entirely on the free Spark plan — no billing account needed. It works alongside EmailJS (if you've set that up too) or on its own if you haven't gotten to EmailJS yet — either way, requests aren't lost.

## Booking form email
The booking form can *also* send you an instant email via EmailJS — this is optional and separate from the dashboard above. See the setup steps Claude gave you earlier, then paste your Service ID, Template ID, and Public Key near the top of `booking.js`.
