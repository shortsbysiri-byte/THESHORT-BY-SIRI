// ---------- Locked background crossfade ----------
const bgLayers = Array.from(document.querySelectorAll('.bg-layer'));
if (bgLayers.length){
  let currentBg = 0;
  let ticking = false;

  function updateBackground(){
    const doc = document.documentElement;
    const scrollable = doc.scrollHeight - window.innerHeight;
    const progress = scrollable > 0 ? window.scrollY / scrollable : 0;
    const index = Math.min(
      bgLayers.length - 1,
      Math.floor(progress * bgLayers.length)
    );
    if (index !== currentBg){
      bgLayers[currentBg].classList.remove('active');
      bgLayers[index].classList.add('active');
      currentBg = index;
    }
    ticking = false;
  }

  window.addEventListener('scroll', () => {
    if (!ticking){
      requestAnimationFrame(updateBackground);
      ticking = true;
    }
  }, { passive:true });
}
