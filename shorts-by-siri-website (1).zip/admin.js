const notConfiguredEl = document.getElementById('notConfigured');
const loginCard = document.getElementById('loginCard');
const dashboard = document.getElementById('dashboard');

if (typeof isFirebaseConfigured !== "function" || !isFirebaseConfigured()){
  notConfiguredEl.style.display = 'block';
  loginCard.style.display = 'none';
  dashboard.style.display = 'none';
} else {

  // ---------- Auth ----------
  const loginForm = document.getElementById('loginForm');
  const loginStatus = document.getElementById('loginStatus');
  const logoutBtn = document.getElementById('logoutBtn');
  const authStatus = document.getElementById('authStatus');

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    loginStatus.textContent = 'Signing in…';
    auth.signInWithEmailAndPassword(loginForm.email.value.trim(), loginForm.password.value)
      .catch(err => {
        console.error(err);
        loginStatus.textContent = 'Sign-in failed: ' + (err.message || 'check your email and password.');
      });
  });

  logoutBtn.addEventListener('click', () => auth.signOut());

  auth.onAuthStateChanged(user => {
    if (user){
      loginCard.style.display = 'none';
      dashboard.style.display = 'block';
      authStatus.textContent = 'Signed in as ' + user.email;
      checkSeeded();
      listenToGallery();
      listenToBookings();
    } else {
      loginCard.style.display = 'block';
      dashboard.style.display = 'none';
      loginStatus.textContent = '';
    }
  });

  // ---------- Seed starter photos (one-time) ----------
  const seedBtn = document.getElementById('seedBtn');
  const seedStatus = document.getElementById('seedStatus');

  async function checkSeeded(){
    const metaDoc = await db.collection('meta').doc('seeded').get();
    if (metaDoc.exists){
      seedBtn.disabled = true;
      seedStatus.textContent = 'Starter photos already imported.';
    }
  }

  seedBtn.addEventListener('click', async () => {
    seedBtn.disabled = true;
    seedStatus.textContent = 'Importing…';
    try{
      const batch = db.batch();
      STATIC_GALLERY.forEach((item, i) => {
        const ref = db.collection('gallery').doc();
        batch.set(ref, {
          url: item.url,
          alt: item.alt,
          highlight: item.highlight,
          order: i,
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
      });
      batch.set(db.collection('meta').doc('seeded'), { done:true });
      await batch.commit();
      seedStatus.textContent = 'Starter photos imported.';
    }catch(err){
      console.error(err);
      seedStatus.textContent = 'Import failed: ' + err.message;
      seedBtn.disabled = false;
    }
  });

  // ---------- Upload new photo ----------
  const uploadForm = document.getElementById('uploadForm');
  const uploadStatus = document.getElementById('uploadStatus');
  const uploadBtn = document.getElementById('uploadBtn');

  uploadForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const file = uploadForm.photo.files[0];
    if (!file){
      uploadStatus.textContent = 'Choose a photo first.';
      return;
    }
    uploadBtn.disabled = true;
    uploadStatus.textContent = 'Uploading…';
    try{
      const path = `gallery/${Date.now()}_${file.name}`;
      const ref = storage.ref().child(path);
      await ref.put(file);
      const url = await ref.getDownloadURL();

      await db.collection('gallery').add({
        url,
        alt: uploadForm.alt.value.trim() || file.name,
        highlight: uploadForm.highlight.checked,
        order: Date.now(),
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        storagePath: path
      });

      uploadStatus.textContent = 'Photo added.';
      uploadForm.reset();
    }catch(err){
      console.error(err);
      uploadStatus.textContent = 'Upload failed: ' + err.message;
    }finally{
      uploadBtn.disabled = false;
    }
  });

  // ---------- Live grid: highlight toggle + delete ----------
  const thumbGrid = document.getElementById('thumbGrid');

  function listenToGallery(){
    db.collection('gallery').orderBy('order', 'asc').onSnapshot(snap => {
      thumbGrid.innerHTML = '';
      if (snap.empty){
        thumbGrid.innerHTML = '<p class="gallery-empty">No photos yet. Import starter photos or upload a new one above.</p>';
        return;
      }
      snap.forEach(doc => {
        const data = doc.data();
        const cell = document.createElement('div');
        cell.className = 'admin-thumb';
        cell.innerHTML = `
          ${data.highlight ? '<span class="badge">Highlight</span>' : ''}
          <img src="${data.url}" alt="${data.alt || ''}">
          <div class="thumb-controls">
            <button class="btn-highlight ${data.highlight ? 'active' : ''}" data-action="highlight">
              ${data.highlight ? 'Unhighlight' : 'Highlight'}
            </button>
            <button class="btn-delete" data-action="delete">Delete</button>
          </div>
        `;
        cell.querySelector('[data-action="highlight"]').addEventListener('click', () => {
          db.collection('gallery').doc(doc.id).update({ highlight: !data.highlight });
        });
        cell.querySelector('[data-action="delete"]').addEventListener('click', async () => {
          if (!confirm('Delete this photo? This cannot be undone.')) return;
          try{
            if (data.storagePath){
              await storage.ref().child(data.storagePath).delete().catch(() => {});
            }
            await db.collection('gallery').doc(doc.id).delete();
          }catch(err){
            console.error(err);
            alert('Could not delete: ' + err.message);
          }
        });
        thumbGrid.appendChild(cell);
      });
    });
  }

  // ---------- Booking requests ----------
  const bookingList = document.getElementById('bookingList');
  const STATUS_CYCLE = ['new', 'contacted', 'done'];

  function formatWhen(ts){
    if (!ts || !ts.toDate) return '';
    return ts.toDate().toLocaleString(undefined, {
      day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit'
    });
  }

  function listenToBookings(){
    db.collection('bookings').orderBy('createdAt', 'desc').onSnapshot(snap => {
      bookingList.innerHTML = '';
      if (snap.empty){
        bookingList.innerHTML = '<p class="gallery-empty">No booking requests yet.</p>';
        return;
      }
      snap.forEach(doc => {
        const b = doc.data();
        const status = b.status || 'new';
        const card = document.createElement('div');
        card.className = 'booking-card';
        card.innerHTML = `
          <div>
            <h3>${b.name || 'Unnamed'} — ${b.service || 'Service not specified'}</h3>
            <p>${b.phone || ''} &middot; ${b.email || ''}</p>
            <p>Preferred date: ${b.date || '—'}${b.location ? ' &middot; ' + b.location : ''}</p>
            ${b.message ? `<p>"${b.message}"</p>` : ''}
            <p class="booking-meta">Submitted ${formatWhen(b.createdAt)}</p>
          </div>
          <div class="booking-actions">
            <button class="status-pill ${status}" data-action="cycle-status">${status}</button>
            <button class="btn-delete" data-action="delete-booking" style="border-radius:6px; padding:6px 12px; font-size:.8rem;">Delete</button>
          </div>
        `;
        card.querySelector('[data-action="cycle-status"]').addEventListener('click', () => {
          const next = STATUS_CYCLE[(STATUS_CYCLE.indexOf(status) + 1) % STATUS_CYCLE.length];
          db.collection('bookings').doc(doc.id).update({ status: next });
        });
        card.querySelector('[data-action="delete-booking"]').addEventListener('click', () => {
          if (!confirm('Delete this booking request?')) return;
          db.collection('bookings').doc(doc.id).delete();
        });
        bookingList.appendChild(card);
      });
    });
  }
}
