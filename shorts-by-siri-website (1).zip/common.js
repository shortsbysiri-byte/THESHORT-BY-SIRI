// ---------- Footer year ----------
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// ---------- Nav shrink on scroll ----------
const nav = document.getElementById('siteNav');
if (nav){
  function updateNav(){
    nav.classList.toggle('scrolled', window.scrollY > 40);
  }
  updateNav();
  window.addEventListener('scroll', updateNav, { passive:true });
}
