// ---------- Static fallback (used until Firebase is configured & seeded) ----------
const STATIC_GALLERY = [
  { url:"assets/gallery/g1.jpg",  alt:"Temple mandapam, first look",        highlight:true  },
  { url:"assets/gallery/g2.jpg",  alt:"A quiet smile mid-ceremony",          highlight:false },
  { url:"assets/gallery/g3.jpg",  alt:"Fairy-lit tunnel, hand in hand",      highlight:true  },
  { url:"assets/gallery/g4.jpg",  alt:"Between rituals, at ease",            highlight:false },
  { url:"assets/gallery/g5.jpg",  alt:"Garlands and golden light",           highlight:false },
  { url:"assets/gallery/g6.jpg",  alt:"A kiss caught mid-laugh",             highlight:true  },
  { url:"assets/gallery/g7.jpg",  alt:"Close, unposed",                      highlight:false },
  { url:"assets/gallery/g8.jpg",  alt:"Sindoor moment",                      highlight:true  },
  { url:"assets/gallery/g9.jpg",  alt:"The bullock cart portrait",           highlight:true  },
  { url:"assets/gallery/g10.jpg", alt:"Same frame, wider light",             highlight:false },
  { url:"assets/gallery/g11.jpg", alt:"Namaste to the mandapam",             highlight:false },
  { url:"assets/gallery/g12.jpg", alt:"Rain, silhouette, doorway",           highlight:false },
  { url:"assets/gallery/g13.jpg", alt:"Hands together, blessing",            highlight:true  },
];

// ---------- Fetch images (Firestore if configured, else static fallback) ----------
async function fetchGalleryImages({ highlightOnly = false, limit = null } = {}){
  if (typeof isFirebaseConfigured === "function" && isFirebaseConfigured() && db){
    try{
      let query = db.collection("gallery").orderBy("order", "asc");
      const snap = await query.get();
      let docs = snap.docs.map(d => ({ id:d.id, ...d.data() }));
      if (highlightOnly) docs = docs.filter(d => d.highlight);
      if (limit) docs = docs.slice(-limit); // most recently added highlights first when limited
      return docs;
    }catch(err){
      console.error("Firestore fetch failed, falling back to static gallery:", err);
    }
  }
  let docs = STATIC_GALLERY.map((d, i) => ({ id:"static-"+i, ...d }));
  if (highlightOnly) docs = docs.filter(d => d.highlight);
  if (limit) docs = docs.slice(0, limit);
  return docs;
}

// ---------- Render a masonry grid into a container ----------
function renderMasonry(container, docs){
  container.innerHTML = "";
  if (!docs.length){
    container.innerHTML = '<p class="gallery-empty">No photos yet — check back soon.</p>';
    return;
  }
  docs.forEach(doc => {
    const item = document.createElement("div");
    item.className = "gallery-item";
    const img = document.createElement("img");
    img.src = doc.url;
    img.alt = doc.alt || "";
    img.loading = "lazy";
    item.appendChild(img);
    container.appendChild(item);
  });
  wireLightbox(container);
}

// ---------- Lightbox (event-delegated so it works with dynamic content) ----------
function wireLightbox(container){
  const lightbox = document.getElementById("lightbox");
  if (!lightbox) return;
  const lbImage = document.getElementById("lbImage");
  let items = Array.from(container.querySelectorAll(".gallery-item img"));
  let idx = 0;

  function open(i){
    idx = i;
    lbImage.src = items[i].src;
    lbImage.alt = items[i].alt;
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden", "false");
  }
  function close(){
    lightbox.classList.remove("open");
    lightbox.setAttribute("aria-hidden", "true");
  }
  function rel(delta){
    idx = (idx + delta + items.length) % items.length;
    lbImage.src = items[idx].src;
    lbImage.alt = items[idx].alt;
  }

  container.querySelectorAll(".gallery-item").forEach((el, i) => {
    el.addEventListener("click", () => open(i));
  });

  const closeBtn = document.getElementById("lbClose");
  const prevBtn = document.getElementById("lbPrev");
  const nextBtn = document.getElementById("lbNext");
  if (closeBtn && !closeBtn.dataset.wired){
    closeBtn.addEventListener("click", close);
    prevBtn.addEventListener("click", () => rel(-1));
    nextBtn.addEventListener("click", () => rel(1));
    lightbox.addEventListener("click", (e) => { if (e.target === lightbox) close(); });
    document.addEventListener("keydown", (e) => {
      if (!lightbox.classList.contains("open")) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") rel(-1);
      if (e.key === "ArrowRight") rel(1);
    });
    closeBtn.dataset.wired = "1";
  }
}
